﻿using UnityEngine;
using System.Collections;

public class DestructibleScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag.Equals("Bullet"))
        {
            Destroy(gameObject,0.05f);
        }
    }


    // Update is called once per frame
	void Update () {
	
	}
}
