﻿using UnityEngine;
using System.Collections;

public class ParallaxEffect : MonoBehaviour
{

    public float percentage;
    private float initialDisplacement;
    private Transform cameraTransform;
	// Use this for initialization
	void Start ()
	{
	    cameraTransform = GameObject.FindGameObjectWithTag("MainCamera").transform;
	    initialDisplacement = cameraTransform.position.x;
	}
	
	// Update is called once per frame
	void Update () {
        transform.position = new Vector3(transform.position.x + percentage*(cameraTransform.position.x-initialDisplacement) , transform.position.y, transform.position.z);
	    initialDisplacement = cameraTransform.position.x;
	}
}
