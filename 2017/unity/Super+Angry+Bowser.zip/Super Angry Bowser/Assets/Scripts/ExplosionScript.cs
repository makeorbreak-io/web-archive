﻿using UnityEngine;
using System.Collections;

public class ExplosionScript : MonoBehaviour
{
    public AudioClip explosionSound;
    public float timeToLive;
	// Use this for initialization
	void Start () {
	
        AudioSource.PlayClipAtPoint(explosionSound,transform.position);
        Invoke("Destroy",timeToLive);
	}

    void Destroy()
    {
        Destroy(gameObject);
    }

	// Update is called once per frame
	void Update () {
	
	}
}
